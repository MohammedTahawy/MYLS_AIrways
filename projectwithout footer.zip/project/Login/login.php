<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="images/W3Schools_2020_2.svg">
    <title>MYLS Airways</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="css/login.css" />
  </head>

  <body>
    <nav class="navbar navbar-expand-lg position-fixed top-0 end-0 start-0">
      <div class="container">
        <img class="logo" src="logo.png" alt="" />
        <div class="navs">
          <button
            class="navbar-toggler text-white"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div
            class="sit offcanvas offcanvas-end"
            tabindex="-1"
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
          >
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item nav-active">
                  <a class="nav-link" aria-current="page" href="../index.html">HOME</a>
                </li>

                <li class="nav-item nav-active">
                  <a class="nav-link" href="../index.html#offers">OFFERS</a>
                </li>

                <li class="nav-item nav-active">
                  <a class="nav-link" href="../index.html#contact">CONTACT US</a>
                </li>

                <li class="nav-item nav-active">
                  <a class="nav-link" href="#">LOGIN</a>
                </li>
                <li class="nav-item nav-active">
                  <a class="nav-link" href="../signup/signup.html">REGISTER</a>
                </li>

                <li class="nav-item nav-active">
                  <a class="nav-link" href="../manage tickets/manage tickets.html"
                    >MANAGE</a
                  >
                </li>

                <li class="nav-item nav-active">
                  <a class="nav-link" href="../Edit/profile.html">EDIT INFO</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>

    <div class="overlay"></div>
    <div class="formContent"> <img src="Screenshot (444).png" class="avatarImg">
      <h2>MYLS</h2>
      <form action="../back/login.php" method="post">
        <label class="E-P">National ID</label>
        <input type="text" name="Nat_id" placeholder="Enter National ID" required class="input_style">
        <label class="E-P">Password</label>
        <input type="password" name="password" placeholder="Enter Password" required class="input_style">
        <br><br>
        <!--<div class="forget"><a href="#">Forget your password?</a></div>-->
        <input type="submit"  value="Login" class="b-login">
        <div class="signup"> 
         <spam>Don't have account? </spam>
         <a href="../signup/signup.html">Signup Now</a> </div>
        </div>
      </form>
     </div>
     <iframe src="" frameborder="0" name="ttt"></iframe>
      <script src="../js/bootstrap.min.js"></script>
  </body>
</html>
