<link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/all.min.css" />
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <link rel="stylesheet" href="css/font.css" />
    <link rel="stylesheet" href="css/main.css" />
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/script.js"></script>
    
    <footer id="contact">
      <div class="footer-img">
        <div class="container h-100">
          <div class="row justify-content-end align-items-center h-100">
            <div class="col-lg-5 text-footer">
              <h2 class="text-edit">Keep In Touch</h2>
              <p class="pt-2">
                FOLLOW MYLS AIRWAYS ON SOCIAL MEDIA TO KEEP UP TO DATE WITH
                LATEST UPDATES.
              </p>
              <h2 class="pt-2">Follow Us On</h2>
              <div class="pt-3">
                <span><i class="fa-brands fa-facebook"></i></span>
                <span><i class="fa-brands fa-twitter"></i></span>
                <span><i class="fa-brands fa-instagram"></i></span>
                <span><i class="fa-brands fa-linkedin"></i></span>
              </div>
            </div>
          </div>
        </div>
        <div class="row m-0">
          <div class="col-lg-12 bg-footer">
            <div class="line pb-3"></div>
            <p class="text-center text-light pt-2 pb-2">
              &copy; 2022 MYLS AIRWAYS, All Rights Reserved
            </p>
          </div>
        </div>
      </div>
    </footer>

    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src="../js/script.js"></script>